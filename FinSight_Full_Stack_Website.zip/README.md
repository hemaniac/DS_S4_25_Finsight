# FinSight — Loan & Credit Risk Analytics

A full-stack academic project demo with a React dashboard and a Python FastAPI + scikit-learn backend.

## Stack
- Frontend: React, Vite, Recharts, Lucide React, custom responsive CSS
- Backend: FastAPI, Pydantic, Pandas, NumPy, scikit-learn
- Persistence: SQLite (prediction history)
- Models: Logistic Regression, Decision Tree, Random Forest
- Data workflow: CSV upload → validation → preprocessing → model training → evaluation → prediction

> **Academic/demo note:** The app starts with a clearly labelled synthetic demonstration dataset. Its scores and predictions are for demonstrating the workflow only. They are not real lending results and must not be used for actual credit decisions. Upload your approved project dataset to run experiments on it.

## Run locally (Windows PowerShell)

### 1. Backend
```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn main:app --reload
```
Backend: http://127.0.0.1:8000  
Interactive API documentation: http://127.0.0.1:8000/docs

### 2. Frontend (open a second terminal)
```powershell
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:5173

The Vite development server proxies `/api` requests to the FastAPI backend.

## CSV format
Required numeric columns:
`credit_score,income,loan_amount,debt_to_income,employment_years,late_payments,age,loan_term`

For model training, include a binary target column named `default` (0 = no recorded default, 1 = recorded default). Optional `applicant_id` is used as an identifier. Download the sample CSV from the app to see the format.

## Important implementation notes
- Preprocessing is fitted inside each model pipeline to reduce leakage.
- A stratified train/test split is used where possible.
- Evaluation includes accuracy, precision, recall, F1-score, ROC-AUC (when calculable), and a confusion matrix.
- SQLite stores prediction history locally.
- The app does not implement real authentication, production security, regulatory compliance, or a real loan approval workflow.

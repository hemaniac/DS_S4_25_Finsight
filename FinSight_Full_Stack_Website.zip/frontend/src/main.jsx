import React, {useEffect, useState} from 'react'
import {createRoot} from 'react-dom/client'
import {AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell} from 'recharts'
import {Activity, ArrowUpRight, BarChart3, Bell, BrainCircuit, BriefcaseBusiness, ChevronDown, CircleHelp, Clock3, Database, Download, FileUp, Gauge, LayoutDashboard, Menu, Search, ShieldCheck, SlidersHorizontal, Sparkles, Users, WalletCards, X, CheckCircle2, AlertTriangle, LoaderCircle} from 'lucide-react'
import './style.css'

const API='/api'
const money=n=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n||0)
const pct=n=>`${(n*100).toFixed(1)}%`
function App(){
 const [page,setPage]=useState('Overview'),[overview,setOverview]=useState(null),[models,setModels]=useState([]),[best,setBest]=useState('Random Forest'),[applicants,setApplicants]=useState([]),[history,setHistory]=useState([]),[loading,setLoading]=useState(true),[toast,setToast]=useState(''),[mobile,setMobile]=useState(false),[uploading,setUploading]=useState(false)
 const [form,setForm]=useState({applicant_id:'FS-NEW-01',credit_score:680,income:650000,loan_amount:450000,debt_to_income:.32,employment_years:5,late_payments:1,age:29,loan_term:36,model:'Random Forest'})
 const [prediction,setPrediction]=useState(null),[predicting,setPredicting]=useState(false)
 async function refresh(){
  setLoading(true)
  try{
   const [o,m,a,h]=await Promise.all([fetch(API+'/overview'),fetch(API+'/models'),fetch(API+'/applicants'),fetch(API+'/history')])
   const ov=await o.json(), md=await m.json(), ap=await a.json(), hi=await h.json()
   setOverview(ov);setModels(md.models||[]);setBest(md.best_model||'Random Forest');setApplicants(ap.items||[]);setHistory(hi.items||[])
  }catch(e){setToast('Backend not connected. Start the FastAPI server first.')}
  finally{setLoading(false)}
 }
 useEffect(()=>{refresh()},[])
 useEffect(()=>{if(toast){const t=setTimeout(()=>setToast(''),3500);return()=>clearTimeout(t)}},[toast])
 async function predict(e){
  e.preventDefault();setPredicting(true);setPrediction(null)
  try{const r=await fetch(API+'/predict',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)});const d=await r.json();if(!r.ok)throw Error(d.detail||'Prediction failed');setPrediction(d);setToast('Risk assessment completed');refresh()}
  catch(e){setToast(e.message)}finally{setPredicting(false)}
 }
 async function upload(e){
  const file=e.target.files?.[0];if(!file)return;setUploading(true)
  const fd=new FormData();fd.append('file',file)
  try{const r=await fetch(API+'/upload',{method:'POST',body:fd});const d=await r.json();if(!r.ok)throw Error(d.detail||'Upload failed');setToast(`${d.rows_used} rows trained successfully`);await refresh()}
  catch(e){setToast(e.message)}finally{setUploading(false);e.target.value=''}
 }
 const nav=[['Overview',LayoutDashboard],['Risk Assessment',Gauge],['Model Lab',BrainCircuit],['Applicants',Users],['Prediction History',Clock3]]
 const active=nav.find(n=>n[0]===page)
 return <div className="app-shell">
  <aside className={`sidebar ${mobile?'open':''}`}>
   <div className="brand"><div className="brand-mark"><Activity size={21}/></div><div><b>FinSight</b><small>RISK INTELLIGENCE</small></div><button className="mobile-close" onClick={()=>setMobile(false)}><X/></button></div>
   <div className="workspace"><span className="workspace-dot"></span><div><b>Credit Analytics</b><small>Academic workspace</small></div><ChevronDown size={15}/></div>
   <div className="nav-label">WORKSPACE</div>
   <nav>{nav.map(([name,Icon])=><button key={name} className={page===name?'nav-item active':'nav-item'} onClick={()=>{setPage(name);setMobile(false)}}><Icon size={18}/><span>{name}</span>{name==='Risk Assessment'&&<span className="nav-new">NEW</span>}</button>)}</nav>
   <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><CircleHelp size={17}/></div><b>Need a walkthrough?</b><p>Explore the model workflow and understand every risk signal.</p><button onClick={()=>setPage('Model Lab')}>Explore model lab <ArrowUpRight size={14}/></button></div><div className="profile"><div className="avatar">FS</div><div><b>FinSight Team</b><small>Project workspace</small></div><ChevronDown size={15}/></div></div>
  </aside>
  <main className="main">
   <header className="topbar"><button className="mobile-menu" onClick={()=>setMobile(true)}><Menu/></button><div className="crumb">Workspace <span>/</span> <b>{page}</b></div><div className="top-actions"><div className="status-pill"><span></span> SYSTEM OPERATIONAL</div><button className="icon-btn" title="Notifications"><Bell size={18}/></button><div className="top-avatar">FS</div></div></header>
   <div className="content">
    <div className="page-heading"><div><div className="eyebrow">FINSIGHT / CREDIT INTELLIGENCE</div><h1>{page==='Overview'?'Understand risk. Make smarter decisions.':page}</h1><p>{page==='Overview'?'A unified view of applicant profiles, credit risk signals and model performance.':page==='Risk Assessment'?'Evaluate an applicant profile using your trained machine-learning models.':page==='Model Lab'?'Compare classification models and inspect evaluation metrics.':page==='Applicants'?'Explore the applicant records currently loaded into the workspace.':'Review recent model-generated risk assessments.'}</p></div><div className="heading-actions"><button className="btn secondary" onClick={()=>refresh()}><Activity size={16}/> Refresh data</button><label className="btn primary upload-btn"><FileUp size={16}/>{uploading?'Uploading...':'Upload dataset'}<input type="file" accept=".csv" onChange={upload} hidden/></label></div></div>
    {overview&&<div className="dataset-banner"><div className="dataset-icon"><Database size={17}/></div><div><b>Active dataset</b><span>{overview.dataset_source}</span></div><span className="demo-tag">DEMO DATA</span><a href={API+'/sample-csv'} download>Download sample CSV <Download size={14}/></a></div>}
    {loading&&!overview?<div className="loading"><LoaderCircle className="spin"/> Connecting to analytics engine…</div>:<>
    {page==='Overview'&&<Overview overview={overview} models={models} applicants={applicants} setPage={setPage}/>}
    {page==='Risk Assessment'&&<section className="assessment-layout"><div className="panel form-panel"><div className="panel-title"><div><h2>Applicant profile</h2><p>Enter the applicant's financial and credit details.</p></div><span className="step-chip">01 / INPUT</span></div><form onSubmit={predict}><div className="form-grid">
      <Field label="Applicant reference" name="applicant_id" value={form.applicant_id} set={setForm} type="text"/>
      <Field label="Credit score" name="credit_score" value={form.credit_score} set={setForm}/>
      <Field label="Annual income (₹)" name="income" value={form.income} set={setForm}/>
      <Field label="Requested loan (₹)" name="loan_amount" value={form.loan_amount} set={setForm}/>
      <Field label="Debt-to-income ratio" name="debt_to_income" value={form.debt_to_income} set={setForm} step="0.01"/>
      <Field label="Employment (years)" name="employment_years" value={form.employment_years} set={setForm}/>
      <Field label="Previous late payments" name="late_payments" value={form.late_payments} set={setForm}/>
      <Field label="Applicant age" name="age" value={form.age} set={setForm}/>
      <Field label="Loan term (months)" name="loan_term" value={form.loan_term} set={setForm}/>
      <div className="field"><label>Prediction model</label><select value={form.model} onChange={e=>setForm({...form,model:e.target.value})}>{models.map(m=><option key={m.name}>{m.name}</option>)}</select></div>
     </div><div className="form-foot"><span><ShieldCheck size={15}/> Inputs are processed by the local API.</span><button className="btn primary large" disabled={predicting}>{predicting?<LoaderCircle className="spin" size={16}/>:<Sparkles size={16}/>} Run risk assessment</button></div></form></div>
     <div className="panel result-panel"><div className="panel-title"><div><h2>Assessment result</h2><p>Model output and probability estimate.</p></div><span className="result-icon"><Gauge size={19}/></span></div>{prediction?<div className="result-content"><div className={prediction.risk==='Higher risk'?'risk-orb high':'risk-orb low'}><span>{Math.round(prediction.probability*100)}<small>%</small></span><label>DEFAULT PROBABILITY</label></div><div className={prediction.risk==='Higher risk'?'risk-label high-text':'risk-label low-text'}>{prediction.risk}</div><p className="result-note">Predicted by {prediction.model} for {prediction.applicant_id}.</p><div className="prob-track"><span style={{width:`${prediction.probability*100}%`}}/></div><div className="result-disclaimer"><AlertTriangle size={15}/> {prediction.note}</div></div>:<div className="empty-result"><div className="empty-glyph"><BrainCircuit size={34}/></div><b>Ready for assessment</b><p>Complete the applicant profile and run the model to see the risk estimate here.</p><div className="mini-steps"><span>01 <b>Enter details</b></span><span>02 <b>Select model</b></span><span>03 <b>Review output</b></span></div></div>}</div></section>}
    {page==='Model Lab'&&<><div className="metric-grid">{models.map((m,i)=><div className="metric-card model-card" key={m.name}><div className="metric-top"><span>{m.name}</span><div className="metric-icon"><BrainCircuit size={17}/></div></div><div className="metric-value">{pct(m.f1)}</div><div className="metric-foot">F1 score <span>{m.name===best?'TOP F1 SCORE':'MODEL RESULT'}</span></div></div>)}</div><div className="panel"><div className="panel-title"><div><h2>Model performance comparison</h2><p>Evaluation on a held-out test partition.</p></div><span className="step-chip">SCIKIT-LEARN</span></div><div className="table-wrap"><table><thead><tr><th>MODEL</th><th>ACCURACY</th><th>PRECISION</th><th>RECALL</th><th>F1 SCORE</th><th>ROC-AUC</th></tr></thead><tbody>{models.map(m=><tr key={m.name}><td><b>{m.name}</b>{m.name===best&&<span className="best-pill">TOP F1</span>}</td><td>{pct(m.accuracy)}</td><td>{pct(m.precision)}</td><td>{pct(m.recall)}</td><td><b>{pct(m.f1)}</b></td><td>{m.auc==null?'—':pct(m.auc)}</td></tr>)}</tbody></table></div></div><div className="panel info-panel"><h3><ShieldCheck size={18}/> How to interpret the metrics</h3><div className="metric-explain"><p><b>Accuracy</b><span>Overall proportion of correct predictions.</span></p><p><b>Precision</b><span>How many predicted higher-risk cases were actually higher risk.</span></p><p><b>Recall</b><span>How many actual higher-risk cases were detected.</span></p><p><b>F1 score</b><span>Harmonic balance between precision and recall.</span></p><p><b>ROC-AUC</b><span>Ranking performance across classification thresholds.</span></p></div></div></>}
    {page==='Applicants'&&<div className="panel"><div className="panel-title"><div><h2>Applicant records</h2><p>Showing a sample of the currently loaded dataset.</p></div><span className="step-chip">{applicants.length} RECORDS</span></div><ApplicantTable applicants={applicants}/></div>}
    {page==='Prediction History'&&<div className="panel"><div className="panel-title"><div><h2>Recent assessments</h2><p>Predictions saved by the backend in SQLite.</p></div><span className="step-chip">LAST 30</span></div>{history.length?<div className="table-wrap"><table><thead><tr><th>REFERENCE</th><th>RISK CLASS</th><th>PROBABILITY</th><th>MODEL</th><th>CREATED</th></tr></thead><tbody>{history.map(h=><tr key={h.id}><td><b>{h.applicant_id}</b></td><td><span className={h.risk==='Higher risk'?'risk-badge high':'risk-badge low'}>{h.risk}</span></td><td>{pct(h.probability)}</td><td>{h.model}</td><td>{new Date(h.created_at+'Z').toLocaleString()}</td></tr>)}</tbody></table></div>:<div className="empty-state"><Clock3 size={28}/><b>No assessments yet</b><span>Run a risk assessment to create your first history record.</span><button className="btn secondary" onClick={()=>setPage('Risk Assessment')}>Start assessment</button></div>}</div>}
    </>}
    <footer className="footer"><span>FinSight · Loan & Credit Risk Analytics</span><span>Academic project interface <i>•</i> For demonstration and learning</span></footer>
   </div>
  </main>
  {toast&&<div className="toast"><CheckCircle2 size={17}/>{toast}<button onClick={()=>setToast('')}><X size={15}/></button></div>}
 </div>
}
function Field({label,name,value,set,type='number',step='any'}){return <div className="field"><label>{label}</label><input type={type} step={step} value={value} onChange={e=>set(p=>({...p,[name]:type==='text'?e.target.value:Number(e.target.value)}))} required/></div>}
function Overview({overview:o,models,applicants,setPage}){
 if(!o)return null
 const best=models.find(m=>m.name===models.sort((a,b)=>b.f1-a.f1)[0]?.name)
 const bar=models.map(m=>({name:m.name.replace(' ','\n'),Accuracy:m.accuracy*100,Precision:m.precision*100,Recall:m.recall*100,F1:m.f1*100}))
 const trend=[{month:'Jan',rate:18},{month:'Feb',rate:21},{month:'Mar',rate:17},{month:'Apr',rate:24},{month:'May',rate:20},{month:'Jun',rate:27},{month:'Jul',rate:23}]
 return <><div className="metric-grid">
  <Metric label="Applicants analysed" value={o.total_applicants.toLocaleString('en-IN')} sub="Records in active dataset" icon={Users} tone="blue"/>
  <Metric label="Recorded defaults" value={o.default_cases.toLocaleString('en-IN')} sub={`${o.default_rate}% of dataset`} icon={AlertTriangle} tone="orange"/>
  <Metric label="Average credit score" value={o.average_credit_score} sub="Mean score across records" icon={Gauge} tone="violet"/>
  <Metric label="Predictions generated" value={o.prediction_count} sub="Saved assessments" icon={Activity} tone="green"/>
 </div>
 <div className="dashboard-grid"><div className="panel chart-panel"><div className="panel-title"><div><h2>Model performance</h2><p>Comparison across core evaluation metrics.</p></div><span className="chart-legend"><i/> Accuracy <i className="purple"/> F1</span></div><ResponsiveContainer width="100%" height={260}><BarChart data={bar} barGap={5}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f5"/><XAxis dataKey="name" tick={{fontSize:11,fill:'#778198'}} axisLine={false} tickLine={false}/><YAxis domain={[0,100]} tick={{fontSize:10,fill:'#778198'}} axisLine={false} tickLine={false}/><Tooltip formatter={v=>`${v.toFixed(1)}%`}/><Bar dataKey="Accuracy" fill="#5978e8" radius={[5,5,0,0]}/><Bar dataKey="F1" fill="#a48af0" radius={[5,5,0,0]}/></BarChart></ResponsiveContainer></div>
 <div className="panel distribution-panel"><div className="panel-title"><div><h2>Outcome distribution</h2><p>Observed target classes</p></div><div className="tiny-icon"><BarChart3 size={17}/></div></div><div className="donut-wrap"><ResponsiveContainer width="100%" height={190}><PieChart><Pie data={o.class_distribution} dataKey="value" nameKey="name" innerRadius={58} outerRadius={82} paddingAngle={4} stroke="none">{o.class_distribution.map((d,i)=><Cell key={i} fill={i===0?'#5b7bea':'#f0a45f'}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer><div className="donut-center"><b>{o.total_applicants}</b><span>RECORDS</span></div></div><div className="legend-list"><span><i className="blue-dot"/> No default <b>{o.class_distribution[0]?.value}</b></span><span><i className="orange-dot"/> Default <b>{o.class_distribution[1]?.value}</b></span></div></div></div>
 <div className="bottom-grid"><div className="panel"><div className="panel-title"><div><h2>Applicant snapshot</h2><p>Recent records from the active dataset.</p></div><button className="text-action" onClick={()=>setPage('Applicants')}>View all <ArrowUpRight size={14}/></button></div><ApplicantTable applicants={applicants.slice(0,5)}/></div><div className="panel insight-panel"><div className="insight-head"><div className="insight-symbol"><Sparkles size={18}/></div><span>MODEL INSIGHT</span></div><h3>{best?.name||'Model comparison'}</h3><p>Currently leads on F1 score in the active evaluation. Review precision and recall alongside F1 before selecting a model.</p><button className="btn secondary" onClick={()=>setPage('Model Lab')}>Explore model results <ArrowUpRight size={14}/></button><div className="insight-watermark"><BrainCircuit size={100}/></div></div></div>
 <div className="notice"><AlertTriangle size={16}/><span><b>Demonstration environment:</b> initial dataset is synthetic and generated for software demonstration. Replace it with your approved dataset before reporting project findings.</span></div>
 </>
}
function Metric({label,value,sub,icon:Icon,tone}){return <div className="metric-card"><div className="metric-top"><span>{label}</span><div className={`metric-icon ${tone}`}><Icon size={18}/></div></div><div className="metric-value">{value}</div><div className="metric-foot">{sub}<ArrowUpRight size={14}/></div></div>}
function ApplicantTable({applicants}){return <div className="table-wrap"><table><thead><tr><th>APPLICANT</th><th>CREDIT SCORE</th><th>ANNUAL INCOME</th><th>LOAN AMOUNT</th><th>OUTCOME</th></tr></thead><tbody>{applicants.map((a,i)=><tr key={a.applicant_id||i}><td><div className="applicant-cell"><div className="table-avatar">{(a.applicant_id||'A').slice(-2)}</div><b>{a.applicant_id}</b></div></td><td>{a.credit_score}</td><td>{money(a.income)}</td><td>{money(a.loan_amount)}</td><td><span className={a.default?'risk-badge high':'risk-badge low'}>{a.default?'Default':'No default'}</span></td></tr>)}</tbody></table></div>}
createRoot(document.getElementById('root')).render(<App/>)

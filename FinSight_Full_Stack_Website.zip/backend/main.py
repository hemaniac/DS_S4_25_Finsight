from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional
from pathlib import Path
import sqlite3, io, csv
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "finsight.db"
FEATURES = ["credit_score", "income", "loan_amount", "debt_to_income",
            "employment_years", "late_payments", "age", "loan_term"]
MODEL_REGISTRY = {}
DATASET = None
DATASET_SOURCE = "Synthetic demonstration data"
app = FastAPI(title="FinSight API", version="1.0.0",
              description="Loan and credit risk analytics API for the FinSight academic project.")

app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            applicant_id TEXT, risk TEXT, probability REAL, model TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )""")

def make_demo_data(n=1200, seed=17):
    rng = np.random.default_rng(seed)
    credit = rng.integers(480, 851, n)
    income = rng.integers(180000, 1800000, n)
    loan = rng.integers(50000, 1800000, n)
    dti = np.clip(rng.normal(0.34, 0.16, n), 0.02, 0.95)
    employment = rng.integers(0, 25, n)
    late = rng.poisson(0.8, n)
    age = rng.integers(21, 66, n)
    term = rng.choice([12, 24, 36, 48, 60], n)
    z = (-0.012*(credit-650) + 2.8*(dti-0.35) + 0.22*late
         - 0.055*employment + 0.00000045*(loan-income*0.7)
         + rng.normal(0, 0.8, n) - 0.2)
    prob = 1/(1+np.exp(-z))
    default = (rng.random(n) < prob).astype(int)
    return pd.DataFrame({
        "applicant_id": [f"FS-{i+1:04d}" for i in range(n)],
        "credit_score": credit, "income": income, "loan_amount": loan,
        "debt_to_income": np.round(dti, 3), "employment_years": employment,
        "late_payments": late, "age": age, "loan_term": term, "default": default
    })

def build_models():
    numeric = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())])
    prep = ColumnTransformer([("numeric", numeric, FEATURES)], remainder="drop")
    return {
        "Logistic Regression": Pipeline([("prep", prep), ("model", LogisticRegression(max_iter=1200, class_weight="balanced"))]),
        "Decision Tree": Pipeline([("prep", prep), ("model", DecisionTreeClassifier(max_depth=6, min_samples_leaf=8, class_weight="balanced", random_state=17))]),
        "Random Forest": Pipeline([("prep", prep), ("model", RandomForestClassifier(n_estimators=180, max_depth=9, min_samples_leaf=4, class_weight="balanced", random_state=17, n_jobs=-1))])
    }

def train(df):
    global MODEL_REGISTRY, DATASET
    missing = [c for c in FEATURES + ["default"] if c not in df.columns]
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))
    clean = df.copy()
    for c in FEATURES + ["default"]:
        clean[c] = pd.to_numeric(clean[c], errors="coerce")
    clean = clean.dropna(subset=["default"])
    clean["default"] = clean["default"].astype(int)
    clean = clean[clean["default"].isin([0, 1])]
    if len(clean) < 40 or clean["default"].nunique() < 2:
        raise ValueError("Dataset needs at least 40 usable rows and both target classes (0 and 1).")
    X, y = clean[FEATURES], clean["default"]
    stratify = y if y.value_counts().min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=stratify
    )
    results, registry = [], {}
    for name, model in build_models().items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        try:
            auc = float(roc_auc_score(y_test, model.predict_proba(X_test)[:, 1]))
        except Exception:
            auc = None
        cm = confusion_matrix(y_test, pred, labels=[0, 1]).tolist()
        row = {
            "name": name, "accuracy": round(float(accuracy_score(y_test, pred)), 4),
            "precision": round(float(precision_score(y_test, pred, zero_division=0)), 4),
            "recall": round(float(recall_score(y_test, pred, zero_division=0)), 4),
            "f1": round(float(f1_score(y_test, pred, zero_division=0)), 4),
            "auc": round(auc, 4) if auc is not None else None, "confusion_matrix": cm
        }
        results.append(row); registry[name] = model
    MODEL_REGISTRY = registry
    DATASET = clean
    return results, len(clean), int(clean["default"].sum())

def save_prediction(applicant_id, risk, probability, model):
    with db() as con:
        con.execute("INSERT INTO predictions(applicant_id,risk,probability,model) VALUES(?,?,?,?)",
                    (applicant_id, risk, probability, model))

class Applicant(BaseModel):
    applicant_id: Optional[str] = "MANUAL-ENTRY"
    credit_score: float = Field(ge=300, le=900)
    income: float = Field(gt=0)
    loan_amount: float = Field(gt=0)
    debt_to_income: float = Field(ge=0, le=1.5)
    employment_years: float = Field(ge=0, le=60)
    late_payments: float = Field(ge=0, le=100)
    age: float = Field(ge=18, le=100)
    loan_term: float = Field(gt=0, le=120)
    model: str = "Random Forest"

@app.on_event("startup")
def startup():
    global DATASET_SOURCE
    init_db()
    df = make_demo_data()
    train(df)
    DATASET_SOURCE = "Synthetic demonstration data"

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "FinSight API"}

@app.get("/api/overview")
def overview():
    if DATASET is None: raise HTTPException(503, "Models are not ready")
    total = len(DATASET); defaults = int(DATASET["default"].sum())
    with db() as con:
        history = con.execute("SELECT COUNT(*) AS n FROM predictions").fetchone()["n"]
    return {
        "total_applicants": total, "default_cases": defaults,
        "default_rate": round(defaults/total*100, 1),
        "average_credit_score": round(float(DATASET.credit_score.mean()), 0),
        "average_income": round(float(DATASET.income.mean()), 0),
        "prediction_count": history, "dataset_source": DATASET_SOURCE,
        "class_distribution": [{"name":"No default", "value":total-defaults},
                               {"name":"Default", "value":defaults}]
    }

@app.get("/api/models")
def models():
    if DATASET is None: raise HTTPException(503, "Models are not ready")
    results, _, _ = train(DATASET)
    return {"models": results, "best_model": max(results, key=lambda x: x["f1"])["name"]}

@app.get("/api/applicants")
def applicants(limit: int = 12):
    if DATASET is None: return {"items": []}
    rows = DATASET.head(max(1, min(limit, 100))).copy()
    items = []
    for _, r in rows.iterrows():
        items.append({"applicant_id": r.get("applicant_id", "Applicant"),
                      "credit_score": int(r.credit_score), "income": float(r.income),
                      "loan_amount": float(r.loan_amount), "debt_to_income": float(r.debt_to_income),
                      "late_payments": int(r.late_payments), "default": int(r.default)})
    return {"items": items}

@app.post("/api/predict")
def predict(payload: Applicant):
    if payload.model not in MODEL_REGISTRY:
        raise HTTPException(400, "Choose a valid trained model.")
    data = pd.DataFrame([{k: getattr(payload, k) for k in FEATURES}])
    model = MODEL_REGISTRY[payload.model]
    probability = float(model.predict_proba(data)[0][1])
    risk = "Higher risk" if probability >= 0.5 else "Lower risk"
    save_prediction(payload.applicant_id or "MANUAL-ENTRY", risk, probability, payload.model)
    return {"applicant_id": payload.applicant_id, "risk": risk,
            "probability": round(probability, 4), "model": payload.model,
            "note": "Demonstration estimate only; not a lending decision."}

@app.get("/api/history")
def history():
    with db() as con:
        rows = con.execute("SELECT * FROM predictions ORDER BY id DESC LIMIT 30").fetchall()
    return {"items": [dict(r) for r in rows]}

@app.get("/api/sample-csv")
def sample_csv():
    sample = make_demo_data(30)
    from fastapi.responses import StreamingResponse
    stream = io.StringIO()
    sample.to_csv(stream, index=False)
    from io import BytesIO
    return StreamingResponse(BytesIO(stream.getvalue().encode()), media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=finsight_sample_dataset.csv"})

@app.post("/api/upload")
async def upload_dataset(file: UploadFile = File(...)):
    global DATASET_SOURCE
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(400, "Please upload a CSV file.")
    raw = await file.read()
    if len(raw) > 10 * 1024 * 1024:
        raise HTTPException(413, "File must be 10 MB or smaller.")
    try:
        df = pd.read_csv(io.BytesIO(raw))
        results, count, defaults = train(df)
        DATASET_SOURCE = file.filename
        return {"message": "Dataset loaded and models trained successfully.",
                "filename": file.filename, "rows_used": count, "default_cases": defaults,
                "models": results}
    except Exception as exc:
        raise HTTPException(400, str(exc))
